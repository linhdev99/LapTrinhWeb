<!DOCTYPE html>
<html>

<head>
  <title>Phần 1 - Bài 1 - Huỳnh Phạm Phước Linh</title>
</head>

<body>
  <?php
  $x = 10;
  $y = 7;
  echo "<hr>";
  echo $x . " + " . $y . " = " . $x + $y;
  echo "<br>";
  echo $x . " - " . $y . " = " . $x - $y;
  echo "<br>";
  echo $x . " * " . $y . " = " . $x * $y;
  echo "<br>";
  echo $x . " / " . $y . " = " . $x / $y;
  echo "<br>";
  echo $x . " % " . $y . " = " . $x % $y;
  echo "<hr>";
  ?>
</body>

</html>