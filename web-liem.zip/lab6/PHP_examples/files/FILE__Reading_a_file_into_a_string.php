<?php
$content = file_get_contents('HTML__Escape_HTML_char.php');

var_dump(htmlspecialchars($content));
?>