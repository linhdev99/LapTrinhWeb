<html>
<head>
<title>An if Statement That Uses else</title>
</head>
<body>
<div>
<?php
    $satisfied = "very";
    if ( $satisfied == "very" ) {
      print "very";
    } else {
      print "not very";
    }
?>
</div>
</body>
</html>